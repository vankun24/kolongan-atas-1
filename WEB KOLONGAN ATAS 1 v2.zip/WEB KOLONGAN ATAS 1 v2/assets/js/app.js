// Theme toggle + persist
(function () {
  const root = document.documentElement;
  const saved = localStorage.getItem('theme');
  if (saved === 'dark' || (!saved && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
    root.classList.add('dark');
  }
  document.getElementById('themeToggle')?.addEventListener('click', () => {
    root.classList.toggle('dark');
    localStorage.setItem('theme', root.classList.contains('dark') ? 'dark' : 'light');
    if (window.feather) feather.replace();
  });
})();

// Init AOS + Feather (hargai reduced motion)
document.addEventListener('DOMContentLoaded', () => {
  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (window.AOS) AOS.init({ once: true, duration: reduce ? 0 : 650, easing: 'ease-out' });
  if (window.feather) feather.replace();
});

// Mobile nav toggle
(function () {
  const btn = document.getElementById('navToggle');
  const menu = document.getElementById('mobileNav');
  btn?.addEventListener('click', () => {
    menu?.classList.toggle('hidden');
    if (window.feather) feather.replace();
  });
})();

/* =========================
   SPA-like navigation (FIX)
   - Re-query #appMain tiap kali (tidak pakai referensi lama)
   - Tanpa flash putih
   ========================= */
(function () {
  const getMain = () => document.getElementById('appMain');
  if (!getMain()) return;

  async function navigate(url, push = true) {
    const mainEl = getMain();
    try {
      mainEl.classList.add('leave');

      const res = await fetch(url, { headers: { 'X-Requested-With': 'fetch' } });
      if (!res.ok) throw new Error('HTTP ' + res.status);

      const html = await res.text();
      const doc = new DOMParser().parseFromString(html, 'text/html');
      const next = doc.getElementById('appMain') || doc.querySelector('main') || doc.body;
      const title = doc.querySelector('title')?.textContent || document.title;

      setTimeout(() => {
        const current = getMain();
        if (!current) { window.location.href = url; return; }

        current.replaceWith(next);
        document.title = title;
        if (push) history.pushState({}, '', url);

        window.scrollTo({ top: 0, behavior: 'auto' });
        if (window.AOS) (AOS.refreshHard?.() || AOS.refresh());
        if (window.feather) feather.replace();

        attachDynamic?.();

        next.classList.add('enter');
        requestAnimationFrame(() => next.classList.add('enter-active'));
        setTimeout(() => next.classList.remove('enter', 'enter-active'), 320);
      }, 80);
    } catch (e) {
      window.location.href = url;
    }
  }

  function intercept(e) {
    const a = e.target.closest('a[href]');
    if (!a) return;

    const href = a.getAttribute('href');
    const tgt = a.getAttribute('target');
    if (!href || tgt === '_blank') return;

    // biarkan anchor lokal & link eksternal
    if (href.startsWith('#')) return;
    if (/^(https?:|mailto:|tel:)/i.test(href)) return;

    // hanya intersep file .html
    if (!/\.html($|[?#])/i.test(href)) return;

    e.preventDefault();
    navigate(href, true);
  }

  document.addEventListener('click', intercept);
  window.addEventListener('popstate', () =>
    navigate(location.pathname + location.search, false)
  );
})();

// Helper fetch JSON
async function loadJSON(path) {
  try {
    const res = await fetch(path, { headers: { 'X-Requested-With': 'fetch' } });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    return await res.json();
  } catch (e) {
    console.warn('Gagal memuat', path, e);
    const el = document.createElement('div');
    el.className = 'max-w-6xl mx-auto px-4 mt-6 p-4 border rounded-xl text-sm';
    el.style.background = '#FEF9C3'; el.style.color = '#713F12';
    el.innerHTML = 'Jika data tidak tampil, jalankan dengan ekstensi <b>Live Server</b> di VS Code.';
    document.body.appendChild(el);
    return null;
  }
}

// Floating WhatsApp
(async function () {
  const cfg = await loadJSON('data/config.json');
  if (!cfg || !cfg.wa_kantor) return;
  const wrap = document.createElement('div');
  wrap.id = 'waFloat';
  wrap.innerHTML = `<a href="https://wa.me/${cfg.wa_kantor}" target="_blank" rel="noopener" aria-label="WhatsApp Kantor"><i data-feather="message-circle"></i><span class="hidden sm:inline">Chat Kantor</span></a>`;
  document.body.appendChild(wrap);
  if (window.feather) feather.replace();
})();

/* ====== Dynamic builder per halaman ====== */
function attachDynamic() {

  // Index – berita terbaru
  (async function () {
    const container = document.getElementById('beritaTerbaru');
    if (!container) return;

    for (let i = 0; i < 3; i++) {
      const sk = document.createElement('div'); sk.className = 'card p-4';
      sk.innerHTML = `<div class="skeleton skel-h40"></div><div class="mt-3 skeleton skel-h20"></div>`;
      container.appendChild(sk);
    }
    const data = await loadJSON('data/berita.json');
    if (!data) return;
    container.innerHTML = '';
    data.sort((a, b) => new Date(b.tanggal) - new Date(a.tanggal));
    const terbaru = data.slice(0, 3);
    const effects = ['fade-up', 'fade-right', 'zoom-in', 'flip-up'];
    terbaru.forEach((b, idx) => {
      const card = document.createElement('article');
      card.className = 'card hover-zoom';
      card.setAttribute('data-aos', effects[idx % effects.length]);
      card.setAttribute('data-aos-delay', String(idx * 70));
      card.innerHTML = `
        <img src="${b.foto}" alt="" class="w-full h-40 object-cover">
        <div class="p-4">
          <div class="text-xs text-slate-500 mb-1">${new Date(b.tanggal).toLocaleDateString('id-ID')}</div>
          <h3 class="font-semibold">${b.judul}</h3>
          <p class="mt-1 text-sm text-slate-600 dark:text-slate-300">${b.ringkas}</p>
          <a class="text-emerald-600 dark:text-emerald-400 text-sm inline-flex items-center gap-1 mt-3 hover:underline" href="berita-detail.html?id=${b.id}">
            <span>Baca selengkapnya</span><i data-feather="arrow-right"></i>
          </a>
        </div>`;
      container.appendChild(card);
    });
    if (window.feather) feather.replace();
    if (window.AOS) AOS.refresh();
  })();

  // Profil
  (async function () {
    const box = document.getElementById('profil');
    if (!box) return;
    const p = await loadJSON('data/profil.json');
    if (!p) return;
    box.innerHTML = `
      <section class="card p-6" data-aos="fade-up">
        <h2 class="text-lg font-semibold mb-2">Sejarah & Letak Geografis</h2>
        <p class="text-slate-700 dark:text-slate-300">${p.sejarah}</p>
        <p class="mt-2 text-slate-700 dark:text-slate-300">${p.letak}</p>
      </section>
      <section class="card p-6" data-aos="zoom-in" data-aos-delay="100">
        <h2 class="text-lg font-semibold mb-2">Visi</h2>
        <p class="text-slate-700 dark:text-slate-300">${p.visi}</p>
        <h2 class="mt-4 text-lg font-semibold mb-2">Misi</h2>
        <ul class="list-disc pl-5 space-y-1">
          ${p.misi.map(m => `<li>${m}</li>`).join('')}
        </ul>
      </section>
      <section class="card p-6" data-aos="flip-up" data-aos-delay="150">
        <h2 class="text-lg font-semibold mb-4">Struktur Pemerintahan</h2>
        <div class="grid sm:grid-cols-2 md:grid-cols-3 gap-3">
          ${p.struktur.map(s => `
            <div class="p-3 border rounded-xl bg-slate-50 dark:bg-slate-800 hover-zoom">
              <div class="text-sm text-slate-500">${s.jabatan}</div>
              <div class="font-medium">${s.nama}</div>
            </div>
          `).join('')}
        </div>
      </section>`;
  })();

  // Layanan
  (async function () {
    const list = document.getElementById('layananList');
    if (!list) return;
    const items = await loadJSON('data/layanan.json');
    const cfg = await loadJSON('data/config.json');
    if (!items || !cfg) return;
    const effects = ['fade-up', 'fade-right', 'zoom-in', 'flip-up'];
    items.forEach((x, idx) => {
      const el = document.createElement('div');
      el.className = 'card p-5 hover-zoom';
      el.setAttribute('data-aos', effects[idx % effects.length]);
      el.setAttribute('data-aos-delay', String(idx * 60));
      el.innerHTML = `
        <h3 class="font-semibold flex items-center gap-2"><i data-feather="check-circle"></i><span>${x.nama}</span></h3>
        <div class="mt-2 text-sm">
          <div class="text-slate-500">Syarat:</div>
          <ul class="list-disc pl-5">${x.syarat.map(s => `<li>${s}</li>`).join('')}</ul>
          <div class="mt-2">Waktu proses: <strong>${x.waktu_proses}</strong></div>
          <div>Biaya: <strong>${x.biaya}</strong></div>
          <div class="text-xs text-slate-500 mt-2">${x.catatan || ''}</div>
        </div>`;
      list.appendChild(el);
    });
    const btn = document.getElementById('btnFormLayanan');
    if (btn) btn.href = cfg.form_layanan_url || '#';
    if (window.feather) feather.replace();
    if (window.AOS) AOS.refresh();
  })();

  // Berita list
  (async function () {
    const list = document.getElementById('beritaList');
    if (!list) return;
    const data = await loadJSON('data/berita.json');
    if (!data) return;
    data.sort((a, b) => new Date(b.tanggal) - new Date(a.tanggal));
    const effects = ['fade-up', 'fade-right', 'zoom-in', 'flip-up'];
    data.forEach((b, idx) => {
      const card = document.createElement('article');
      card.className = 'card hover-zoom';
      card.setAttribute('data-aos', effects[idx % effects.length]);
      card.setAttribute('data-aos-delay', String(Math.min(idx * 40, 220)));
      card.innerHTML = `
        <img src="${b.foto}" alt="" class="w-full h-40 object-cover">
        <div class="p-4">
          <div class="text-xs text-slate-500 mb-1">${new Date(b.tanggal).toLocaleDateString('id-ID')}</div>
          <h3 class="font-semibold">${b.judul}</h3>
          <p class="mt-1 text-sm text-slate-600 dark:text-slate-300">${b.ringkas}</p>
          <a class="text-emerald-600 dark:text-emerald-400 text-sm inline-flex items-center gap-1 mt-3 hover:underline" href="berita-detail.html?id=${b.id}">
            <span>Baca selengkapnya</span><i data-feather="arrow-right"></i>
          </a>
        </div>`;
      list.appendChild(card);
    });
    if (window.feather) feather.replace();
    if (window.AOS) AOS.refresh();
  })();

  // Berita detail
  (async function () {
    const box = document.getElementById('beritaDetail');
    if (!box) return;
    const data = await loadJSON('data/berita.json');
    const url = new URL(window.location.href);
    const id = url.searchParams.get('id');
    const item = data?.find(x => x.id === id) || data?.[0];
    if (!item) { box.textContent = 'Berita tidak ditemukan.'; return; }
    box.setAttribute('data-aos', 'fade-up');
    box.innerHTML = `
      <div class="text-xs text-slate-500">${new Date(item.tanggal).toLocaleDateString('id-ID')}</div>
      <h1 class="text-2xl font-bold mt-1">${item.judul}</h1>
      <img src="${item.foto}" class="w-full h-64 object-cover rounded-xl mt-4" alt="">
      <div class="prose dark:prose-invert mt-4 max-w-none">${item.isi}</div>
    `;
    if (window.feather) feather.replace();
    if (window.AOS) AOS.refresh();
  })();

  // Agenda
  (async function () {
    const list = document.getElementById('agendaList');
    if (!list) return;
    const data = await loadJSON('data/agenda.json');
    if (!data) return;
    const effects = ['fade-up', 'fade-right', 'zoom-in', 'flip-up'];
    data.sort((a, b) => new Date(a.tanggal) - new Date(b.tanggal));
    data.forEach((a, idx) => {
      const el = document.createElement('div');
      el.className = 'card p-5 hover-zoom';
      el.setAttribute('data-aos', effects[idx % effects.length]);
      el.setAttribute('data-aos-delay', String(idx * 40));
      el.innerHTML = `
        <div class="text-xs text-slate-500">${new Date(a.tanggal).toLocaleDateString('id-ID')}</div>
        <h3 class="font-semibold mt-1 flex items-center gap-2"><i data-feather="calendar"></i><span>${a.judul}</span></h3>
        <div class="text-sm mt-1"><span class="text-slate-500">Lokasi:</span> ${a.lokasi}</div>
        <p class="text-sm text-slate-600 dark:text-slate-300 mt-2">${a.deskripsi}</p>
      `;
      list.appendChild(el);
    });
    if (window.feather) feather.replace();
    if (window.AOS) AOS.refresh();
  })();

  // Pengaduan – button link
  (async function () {
    const btn = document.getElementById('btnFormPengaduan');
    if (!btn) return;
    const cfg = await loadJSON('data/config.json');
    if (!cfg) return;
    btn.href = cfg.form_pengaduan_url || '#';
  })();

  // Statistik
  (async function () {
    const box = document.getElementById('stat');
    if (!box) return;
    const s = await loadJSON('data/statistik.json');
    if (!s) return;
    const card = (title, content, idx = 0) => {
      const c = document.createElement('div');
      c.className = 'card p-5 hover-zoom';
      const effects = ['fade-up', 'fade-right', 'zoom-in', 'flip-up'];
      c.setAttribute('data-aos', effects[idx % effects.length]);
      c.setAttribute('data-aos-delay', String(idx * 60));
      c.innerHTML = `<h3 class="font-semibold">${title}</h3>${content}`;
      return c;
    };
    const list = (obj) => `<ul class="mt-2 list-disc pl-5">${Object.entries(obj).map(([k, v]) => `<li>${k}: <strong>${v}</strong></li>`).join('')}</ul>`;
    box.appendChild(card('Total Penduduk', `<div class="text-3xl font-bold mt-2">${s.penduduk_total}</div>
          <div class="text-sm mt-2">Laki-laki: <strong>${s.laki_laki}</strong> • Perempuan: <strong>${s.perempuan}</strong></div>`, 0));
    box.appendChild(card('Sebaran Usia', list(s.usia), 1));
    box.appendChild(card('Pendidikan', list(s.pendidikan), 2));
    box.appendChild(card('Pekerjaan', list(s.pekerjaan), 3));
    if (window.AOS) AOS.refresh();
  })();
}

// Panggil pertama kali
document.addEventListener('DOMContentLoaded', attachDynamic);
